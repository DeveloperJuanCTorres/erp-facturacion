<section class="content-header no-print">
    <h1>
        <?php echo e($title, false); ?>

        <?php if(!empty($subtitle)): ?>
            <small><?php echo e($subtitle, false); ?></small>
        <?php endif; ?>
    </h1>
</section>
<?php /**PATH /home/u997099361/domains/demochatnacionalcode.website/public_html/Modules/Accounting/Providers/../Resources/views/components/section_header.blade.php ENDPATH**/ ?>