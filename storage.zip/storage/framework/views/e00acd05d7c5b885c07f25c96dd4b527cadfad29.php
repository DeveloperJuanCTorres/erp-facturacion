<?php if(session('status')): ?>
    <input type="hidden" id="status_span" data-status="<?php echo e(session('status.success'), false); ?>" data-msg="<?php echo e(session('status.msg'), false); ?>">
<?php endif; ?>


<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__env->startComponent('accounting::components.alert', ['type' => 'danger']); ?>
            <?php echo e($error, false); ?>

        <?php echo $__env->renderComponent(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>


<?php if(session('error')): ?>
    <?php $__env->startComponent('accounting::components.alert', ['type' => 'danger']); ?>
        <?php echo e(session('error'), false); ?>

    <?php echo $__env->renderComponent(); ?>
<?php endif; ?>


<?php if(session('warning')): ?>
    <?php $__env->startComponent('accounting::components.alert', ['type' => 'warning']); ?>
        <?php echo e(session('warning'), false); ?>

    <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /home/u997099361/domains/demochatnacionalcode.website/public_html/Modules/Accounting/Providers/../Resources/views/layouts/partials/alert-feedback.blade.php ENDPATH**/ ?>