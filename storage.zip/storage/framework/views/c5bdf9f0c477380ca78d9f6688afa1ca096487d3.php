<?php $__env->startSection('title'); ?>
    <?php echo $__env->yieldContent('tab-title'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('accounting::layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <section class="content-header">
        <h1>
            <?php echo e(trans_choice('accounting::general.accounting', 1), false); ?> <?php echo e(trans_choice('accounting::lang.settings', 1), false); ?>

        </h1>
    </section>

    <div id="vue-app-with-modal">
        
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    
                    <div class="col-xs-12 pos-tab-container">
                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 pos-tab-menu">
                            
                            <div class="list-group-link">
                                <?php
                                    $nav_items = [
                                        'accounting/settings/account_subtypes' => ' ' . trans_choice('accounting::general.account_subtype', 2),
                                        'accounting/settings/detail_types' => ' ' . trans_choice('accounting::general.detail_type', 2),
                                    ];
                                    
                                    function isActiveTab($url)
                                    {
                                        $first_three_segments = request()->segment(1) . '/' . request()->segment(2) . '/' . request()->segment(3);
                                        return $first_three_segments == $url;
                                    }
                                ?>

                                
                                <?php $__currentLoopData = $nav_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(url($url), false); ?>"
                                        class="list-group-item text-center <?php if(isActiveTab($url)): ?> active <?php endif; ?>">
                                        <?php echo e($label, false); ?>

                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                        <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 pos-tab">
                            <?php echo $__env->yieldContent('tab-content'); ?>
                        </div>
                    </div>
                    
                </div>
            </div>
        </section>
        

        <?php echo $__env->yieldContent('tab-modal-content'); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <?php echo $__env->yieldContent('tab-javascript'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('accounting::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u997099361/domains/demochatnacionalcode.website/public_html/Modules/Accounting/Providers/../Resources/views/settings/layout.blade.php ENDPATH**/ ?>