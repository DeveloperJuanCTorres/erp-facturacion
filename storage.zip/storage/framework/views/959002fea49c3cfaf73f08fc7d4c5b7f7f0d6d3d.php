<div class="modal fade" id="createAccountSubtypeModal" tabindex="-1" role="dialog" aria-labelledby="createAccountSubtypeModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createAccountSubtypeModalLabel">
                    <?php echo e(trans('accounting::lang.create'), false); ?> <?php echo e(trans('account.account'), false); ?>

                    <?php echo e(trans_choice('accounting::general.account_subtype', 1), false); ?>

                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <form action="<?php echo e(url('accounting/settings/account_subtypes/store'), false); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">

                    <div class="form-group">
                        <label for="account_type" class="control-label"><?php echo e(trans_choice('accounting::general.account', 1), false); ?>

                            <?php echo e(trans_choice('accounting::lang.type', 1), false); ?> </label>
                        <v-select label="name" :options="account_types" :reduce="account => account.id" id="account_type"
                            v-model="account_type">
                            <template #search="{attributes, events}">
                                <input autocomplete="off" class="vs__search <?php $__errorArgs = ['account_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" v-bind="attributes"
                                    v-bind:required="!account_type" v-on="events" />
                            </template>
                        </v-select>
                        <input type="hidden" name="account_type" v-model="account_type">
                        <?php $__errorArgs = ['account_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message, false); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="name"><?php echo e(trans('accounting::lang.name'), false); ?></label>
                        <input class="form-control" type="text" name="name" id="name" v-model="name">
                    </div>

                    <div class="form-group">
                        <label for="description"><?php echo e(trans('accounting::lang.description'), false); ?></label>
                        <textarea class="form-control" type="text" name="description" id="description" v-model="description"></textarea>
                    </div>

                    <div class="form-group">
                        <div class="checkbox">
                            <label>
                                <input class="input-icheck" name="active" type="checkbox" v-model="active">
                                <?php echo e(trans('accounting::lang.active'), false); ?>

                            </label>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>

            </form>

        </div>
    </div>
</div>
<?php /**PATH /home/u997099361/domains/demochatnacionalcode.website/public_html/Modules/Accounting/Providers/../Resources/views/settings/account_subtypes/create.blade.php ENDPATH**/ ?>