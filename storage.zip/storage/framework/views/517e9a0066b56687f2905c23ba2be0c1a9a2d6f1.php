<div class="container-fluid" style="overflow-y: hidden; overflow-x: auto; width: 100%">
    <div class="box box-primary">

        <?php if (! (empty($title) && empty($header))): ?>
            <div class="box-header">
                <?php if (! (empty($title))): ?>
                    <h3 class="box-title"><?php echo e($title, false); ?></h3>
                <?php endif; ?>

                
                <?php if (! (empty($header))): ?>
                    <?php echo e($header, false); ?>

                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="box-body">
            <?php echo e($body, false); ?>

        </div>
        <!-- /.box-body -->

        <?php if (! (empty($footer))): ?>
            <div class="box-footer">
                <?php echo e($footer, false); ?>

            </div>
        <?php endif; ?>
    </div>

</div>
<?php /**PATH /home/u997099361/domains/demochatnacionalcode.website/public_html/Modules/Accounting/Providers/../Resources/views/components/box.blade.php ENDPATH**/ ?>